<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title>GSM-TC SORGULAMA TERMINAL</title>

    <link href="https://fonts.googleapis.com/css2?family=VT323&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    :root {
        --font-base: clamp(1.05rem, 3.8vw + 0.4rem, 1.45rem);
        --font-label: clamp(1.1rem, 4vw + 0.3rem, 1.4rem);
        --font-small: clamp(0.95rem, 3.2vw + 0.3rem, 1.25rem);
        --spacing-sm: clamp(0.8rem, 4vw, 1.2rem);
        --spacing-md: clamp(1.2rem, 5vw, 1.8rem);
    }

    body {
        font-family: 'VT323', monospace;
        background: #00060f;
        color: #00f0ff;
        min-height: 100vh;
        padding: var(--spacing-sm);
        line-height: 1.4;
        font-size: var(--font-base);
    }

    .scanline {
        position: fixed;
        inset: 0;
        pointer-events: none;
        background: repeating-linear-gradient(to bottom, transparent 0, rgba(0, 240, 255, 0.04) 1px, transparent 3px);
        animation: scan 14s linear infinite;
        opacity: 0.6;
        z-index: -1;
    }

    @keyframes scan {
        0% {
            transform: translateY(-120%);
        }

        100% {
            transform: translateY(220%);
        }
    }

    .container {
        max-width: 800px;
        margin: 0 auto;
        width: 100%;
    }

    .back-btn {
        display: inline-flex;
        align-items: center;
        gap: 0.6rem;
        color: #00e0ff;
        text-decoration: none;
        font-size: clamp(1.1rem, 4vw, 1.35rem);
        padding: 0.6rem 1.1rem;
        border: 1px solid #00f0ff40;
        background: rgba(0, 20, 40, 0.4);
        margin: 1rem 0 1.8rem;
        transition: all 0.2s;
        touch-action: manipulation;
    }

    .back-btn:hover,
    .back-btn:active {
        background: rgba(0, 40, 80, 0.6);
        box-shadow: 0 0 16px #00f0ff50;
    }

    .terminal-panel {
        background: rgba(0, 10, 20, 0.85);
        border: 1px solid #00f0ff30;
        box-shadow: 0 0 30px rgba(0, 240, 255, 0.15);
        margin-bottom: 2rem;
        overflow: hidden;
        border-radius: 4px;
    }

    .panel-header {
        background: #001428;
        border-bottom: 1px solid #00f0ff40;
        padding: clamp(0.8rem, 3vw, 1rem) clamp(1rem, 4vw, 1.3rem);
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 0.8rem;
        font-size: clamp(1.2rem, 4.5vw, 1.45rem);
    }

    .header-title {
        display: flex;
        align-items: center;
        gap: 0.7rem;
        flex: 1;
    }

    .demo-badge {
        background: rgba(255, 0, 170, 0.25);
        color: #ff44cc;
        border: 1px solid #ff00aa60;
        padding: 0.3rem 0.8rem;
        font-size: clamp(0.9rem, 3.5vw, 1rem);
        border-radius: 3px;
    }

    .form-content {
        padding: var(--spacing-md);
    }

    .field {
        margin-bottom: 1.5rem;
    }

    .field label {
        display: block;
        color: #88ffff;
        font-size: var(--font-label);
        margin-bottom: 0.5rem;
    }

    input {
        width: 100%;
        background: #00060f;
        border: 1px solid #00f0ff50;
        color: #00f0ff;
        font-size: var(--font-base);
        padding: 0.8rem 1rem;
        font-family: inherit;
        border-radius: 3px;
    }

    input:focus {
        outline: none;
        border-color: #00f0ff;
        box-shadow: 0 0 14px rgba(0, 240, 255, 0.5);
        background: #00111a;
    }

    .buttons {
        display: flex;
        flex-direction: row;
        gap: 1rem;
        flex-wrap: wrap;
        margin-top: 1.2rem;
    }

    .btn {
        flex: 1;
        min-width: 140px;
        background: transparent;
        border: 2px solid;
        font-size: clamp(1.15rem, 4.2vw, 1.35rem);
        padding: 0.8rem 1rem;
        cursor: pointer;
        transition: all 0.18s;
        text-align: center;
        letter-spacing: 1.2px;
        border-radius: 4px;
        touch-action: manipulation;
    }

    .btn-search {
        border-color: #00d0ff;
        color: #00e0ff;
        box-shadow: 0 0 12px rgba(0, 208, 255, 0.4);
    }

    .btn-search:hover,
    .btn-search:active {
        background: rgba(0, 208, 255, 0.18);
        box-shadow: 0 0 24px rgba(0, 208, 255, 0.7);
    }

    .btn-clear {
        border-color: #ff33aa;
        color: #ff66cc;
        box-shadow: 0 0 10px rgba(255, 51, 170, 0.4);
    }

    .btn-clear:hover,
    .btn-clear:active {
        background: rgba(255, 51, 170, 0.18);
        box-shadow: 0 0 22px rgba(255, 51, 170, 0.7);
    }

    .output-content {
        min-height: 140px;
        padding: var(--spacing-md);
        color: #bbffff;
        font-size: var(--font-base);
        line-height: 1.5;
        white-space: pre-wrap;
        word-break: break-word;
    }

    .placeholder-text {
        color: #557799;
        text-align: center;
        padding: 2rem 1rem;
        font-size: var(--font-small);
    }

    .error-text {
        color: #ff6666;
        line-height: 1.5;
    }

    /* ────────────────────────────────────────────── */
    /* MOBILE / SMALL SCREEN OPTIMIZATIONS          */
    /* ────────────────────────────────────────────── */

    @media (max-width: 640px) {
        body {
            padding: 0.8rem;
        }

        .container {
            padding: 0 0.4rem;
        }

        .back-btn {
            font-size: clamp(1rem, 4.5vw, 1.2rem);
            padding: 0.5rem 1rem;
            width: 100%;
            justify-content: center;
            margin: 0.8rem 0 1.5rem;
        }

        .panel-header {
            font-size: clamp(1.1rem, 5vw, 1.3rem);
            flex-direction: column;
            align-items: flex-start;
            gap: 0.5rem;
            padding: 0.8rem 1rem;
        }

        .demo-badge {
            align-self: flex-start;
        }

        .form-content {
            padding: 1.2rem 1rem;
        }

        .buttons {
            flex-direction: column;
            gap: 0.8rem;
        }

        .btn {
            min-width: unset;
            width: 100%;
            padding: 0.9rem;
            font-size: clamp(1.1rem, 5vw, 1.3rem);
        }

        .output-content {
            font-size: clamp(1.05rem, 4.2vw, 1.25rem);
            padding: 1.2rem 1rem;
        }

        .field label {
            font-size: clamp(1rem, 4.5vw, 1.25rem);
        }

        input {
            font-size: clamp(1.1rem, 5vw, 1.3rem);
            padding: 0.7rem 0.9rem;
        }
    }

    @media (max-width: 380px) {
        .panel-header {
            font-size: 1.15rem;
        }

        .output-content {
            font-size: 1.1rem;
        }
    }
    </style>
</head>

<body>

    <div class="container">
        <a href="index.php" class="back-btn">
            <i class="ri-arrow-left-s-line"></i>
            ANASAYFAYA DÖN
        </a>

        <div class="terminal-panel">
            <div class="panel-header">
                <i class="ri-user-search-line"></i>
                GSM SORGULAMA
            </div>
            <div class="form-content">
                <div class="field">
                    <label>Gsm No</label>
                    <input type="text" id="tc" placeholder="örn: 5458000000" maxlength="10" inputmode="numeric">
                </div>
                <div class="buttons">
                    <button id="sorgula" class="btn btn-search"><i class="ri-search-line"></i> SORGULA</button>
                    <button id="temizle" class="btn btn-clear"><i class="ri-close-line"></i> TEMİZLE</button>
                </div>
            </div>
        </div>

        <div class="terminal-panel">
            <div class="panel-header">
                <i class="ri-terminal-line"></i>
                SONUÇLAR
            </div>
            <div class="output-content" id="sonucAlani">
                <div class="placeholder">GSM numarası girip SORGULA'ya basın</div>
            </div>
        </div>

    </div>

    <script>
    $(function() {

        $("#sorgula").click(function() {
            let tc = $("#tc").val().trim();
            if (tc.length !== 10 || !/^\d{10}$/.test(tc)) {
                $("#sonucAlani").html('<div class="error-text">Geçerli 11 haneli TC giriniz!</div>');
                return;
            }

            $("#sonucAlani").html('Sorgulanıyor...');

            $.ajax({
                url: "https://belsis.store/api/req/gsmtc.php",
                type: "GET",
                headers: {
                    "X-Requested-With": "XMLHttpRequest"
                },
                data: {
                    tckn: tc
                },
                dataType: "json",
                timeout: 10000,
                success: function(res) {

                    if (!res || !res.data || !Array.isArray(res.data) || res.data.length ===
                        0) {
                        $("#sonucAlani").html(
                            '<div class="error-text">Kayıt bulunamadı</div>');
                        return;
                    }

                    let html = '';

                    res.data.forEach((d, i) => {
                        let yas = '-';
                        if (d.DG) {
                            let p = d.DG.split('.');
                            if (p.length === 3) {
                                let dogum = new Date(p[2], p[1] - 1, p[0]);
                                yas = Math.floor((new Date() - dogum) /
                                31557600000);
                            }
                        }

                        html += `
                    <div class="result-item">
                        <div class="result-item-header">
                            Kayıt ${i + 1} → ${d.ADI || '?'} ${d.SOYADI || '?'}
                        </div>
                        <table class="result-table">
                            <tr><td class="label">T.C. No</td><td class="value">${d.TCKN || '-'}</td></tr>
                            <tr><td class="label">Ad Soyad</td><td class="value">${d.ADI || '-'} ${d.SOYADI || '-'}</td></tr>
                            <tr><td class="label">Doğum Tarihi</td><td class="value">${d.DG || '-'}</td></tr>
                            <tr><td class="label">Yaş</td><td class="value">${yas}</td></tr>
                            <tr><td class="label">Anne Adı / TC</td><td class="value">${d.ANNEADI || '-'} (${d.ANNETCKN || '-'})</td></tr>
                            <tr><td class="label">Baba Adı / TC</td><td class="value">${d.BABAADI || '-'} (${d.BABATCKN || '-'})</td></tr>
                            <tr><td class="label">İl / İlçe</td><td class="value">${d.ILILCE || '-'}</td></tr>
                            <tr><td class="label">Adres</td><td class="value">${d.ADRES || 'Kayıtlı değil'}</td></tr>
                            <tr><td class="label">GSM</td><td class="value">${d.GSM || 'Kayıtlı değil'}</td></tr>
                        </table>
                    </div>`;
                    });

                    $("#sonucAlani").html(html);
                },
                error: function() {
                    $("#sonucAlani").html('<div class="error-text">Bağlantı hatası</div>');
                }
            });
        });

        $("#temizle").click(function() {
            $("#tc").val('');
            $("#sonucAlani").html('<div class="placeholder">Sonuç bekleniyor...</div>');
        });

        $("#tc").on('keypress', e => {
            if (e.which === 13) $("#sorgula").click();
        });
    });
    </script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"6d4f86e12adf4d968b54383ca34ca6a5","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>

</html>