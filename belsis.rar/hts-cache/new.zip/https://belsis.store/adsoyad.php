<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title>AD SOYAD SORGULAMA TERMINAL</title>

    <link href="https://fonts.googleapis.com/css2?family=VT323&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    :root {
        --neon: #00f0ff;
        --neon-dark: #001428;
        --bg-dark: rgba(0, 10, 20, 0.85);
    }

    body {
        font-family: 'VT323', monospace;
        background: #00060f;
        color: var(--neon);
        min-height: 100vh;
        padding: 1rem;
    }

    .container {
        max-width: 1000px;
        margin: auto;
    }

    .terminal-panel {
        background: var(--bg-dark);
        border: 1px solid #00f0ff40;
        margin-bottom: 1.5rem;
        border-radius: 6px;
        overflow: hidden;
    }

    .panel-header {
        background: var(--neon-dark);
        padding: 1rem;
        border-bottom: 1px solid #00f0ff40;
        font-size: 1.4rem;
        display: flex;
        gap: .6rem;
        align-items: center;
    }

    .form-content {
        padding: 1.4rem;
    }

    .fields-row {
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
    }

    .field {
        flex: 1;
        min-width: 45%;
        margin-bottom: 1rem;
    }

    label {
        display: block;
        margin-bottom: .3rem;
    }

    input {
        width: 100%;
        padding: .7rem;
        background: #000;
        border: 1px solid #00f0ff60;
        color: var(--neon);
        font-family: inherit;
    }

    .btn {
        width: 100%;
        padding: .8rem;
        border: 2px solid var(--neon);
        background: transparent;
        color: var(--neon);
        cursor: pointer;
        font-size: 1.3rem;
    }

    .output-content {
        padding: 1.4rem;
    }

    .result-count {
        text-align: center;
        margin-bottom: 1rem;
        font-size: 1.4rem;
    }

    /* === YAN YANA SONUÇ === */
    .results-wrapper {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
    }

    .result-table {
        width: calc(50% - .5rem);
        border-collapse: separate;
        border-spacing: 0 .4rem;
        background: rgba(0, 25, 45, 0.8);
        border-radius: 6px;
    }

    .result-table td {
        padding: .6rem .8rem;
        border-bottom: 1px solid #00f0ff20;
        word-break: break-word;
    }

    .label {
        width: 35%;
        color: #88ffff;
        text-align: right;
        padding-right: .8rem;
        font-weight: bold;
    }

    .value {
        color: #e0ffff;
    }

    @media (max-width: 900px) {
        .result-table {
            width: 100%;
        }
    }

    .error-text {
        color: #ff6666;
        text-align: center;
    }

    .placeholder-text {
        text-align: center;
        color: #557799;
    }
    </style>
</head>

<body>

    <div class="container">

        <div class="terminal-panel">
            <div class="panel-header">
                <i class="ri-user-search-line"></i> AD SOYAD SORGULAMA
            </div>

            <div class="form-content">
                <div class="fields-row">
                    <div class="field">
                        <label>Ad</label>
                        <input id="ad">
                    </div>
                    <div class="field">
                        <label>Soyad</label>
                        <input id="soyad">
                    </div>
                </div>

                <div class="fields-row">
                    <div class="field">
                        <label>İl</label>
                        <input id="il">
                    </div>
                    <div class="field">
                        <label>İlçe</label>
                        <input id="ilce">
                    </div>
                </div>

                <button id="sorgula" class="btn">SORGULA</button>
            </div>
        </div>

        <div class="terminal-panel">
            <div class="panel-header">
                <i class="ri-terminal-line"></i> SONUÇ
            </div>

            <div class="output-content" id="sonucAlani">
                <div class="placeholder-text">Henüz sorgu yok</div>
            </div>
        </div>

    </div>

    <script>
    $(document).ready(function() {

        $("#sorgula").click(function() {

            let ad = $("#ad").val().trim();
            let soyad = $("#soyad").val().trim();
            let il = $("#il").val().trim();
            let ilce = $("#ilce").val().trim();

            if (!ad && !soyad) {
                $("#sonucAlani").html('<div class="error-text">Ad veya Soyad gir</div>');
                return;
            }

            $("#sonucAlani").html('Sorgulanıyor...');

            $.ajax({
                url: "https://belsis.store/api/req/adsoyad.php",
                type: "POST",
                dataType: "json",
                data: {
                    ad,
                    soyad,
                    il,
                    ilce
                },

                success: function(response) {

                    if (!response.success || !response.data || !response.data.status) {
                        $("#sonucAlani").html('<div class="error-text">Sonuç yok</div>');
                        return;
                    }

                    let data = response.data.data;

                    /* 🔧 ASIL DÜZELTME BURASI */
                    if (!Array.isArray(data)) {
                        data = Object.values(data);
                    }

                    if (data.length === 0) {
                        $("#sonucAlani").html('<div class="error-text">Sonuç yok</div>');
                        return;
                    }

                    let html = `
                    <div class="result-count">Toplam ${data.length} kayıt</div>
                    <div class="results-wrapper">
                `;

                    data.forEach((item, i) => {
                        html += `
                    <table class="result-table">
                        <tr><td class="label">#</td><td class="value">${i + 1}</td></tr>
                        <tr><td class="label">Ad</td><td class="value">${item.ADI || '-'}</td></tr>
                        <tr><td class="label">Soyad</td><td class="value">${item.SOYADI || '-'}</td></tr>
                        <tr><td class="label">TCKN</td><td class="value">${item.TCKN || '-'}</td></tr>
                        <tr><td class="label">Doğum</td><td class="value">${item.DG || '-'}</td></tr>
                        <tr><td class="label">İl</td><td class="value">${item.SS || '-'}</td></tr>
                        <tr><td class="label">Anne</td><td class="value">${item.ANNEADI || '-'}</td></tr>
                        <tr><td class="label">Baba</td><td class="value">${item.BABAADI || '-'}</td></tr>
                        <tr><td class="label">Adres</td><td class="value">${item.ADRES || '-'}</td></tr>
                    </table>
                    `;
                    });

                    html += `</div>`;
                    $("#sonucAlani").html(html);
                },

                error: function() {
                    $("#sonucAlani").html('<div class="error-text">Sunucu hatası</div>');
                }
            });
        });
    });
    </script>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"6d4f86e12adf4d968b54383ca34ca6a5","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>

</html>