<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belsis Zorbalık Hizmeti 2026 | En İyi Siber Zorbalık Hizmeti (VPN İLE GİRİŞ YAPINIZ)</title>
    <meta name="description"
        content="🔥 Bedava Sorgu Paneli 2026 - Türkiye'nin En İyi Ücretsiz Sorgu Paneli! Sorgu Paneli, GSM Sorgu Paneli, Adres Sorgu Paneli. Online Sorgu Paneli ile hızlı sorgulama.">
    <meta name="keywords"
        content="sorgu paneli, bedava sorgu paneli, ücretsiz sorgu paneli, online sorgu paneli, tc sorgu paneli, gsm sorgu paneli, adres sorgu paneli, tapu sorgu paneli, kimlik sorgu paneli, telefon sorgu paneli, en iyi sorgu paneli, hızlı sorgu paneli, güvenli sorgu paneli, sorgu paneli 2026, türkiye sorgu paneli">


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=VT323&display=swap" rel="stylesheet">

    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=VT323&display=swap');

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Inter', 'VT323', monospace, sans-serif;
        background: #050505;
        min-height: 100vh;
        color: #e0f0ff;
        overflow-x: hidden;
    }

    .ai-grid {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0.06;
        background-image:
            linear-gradient(rgba(0, 240, 255, 0.08) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 240, 255, 0.08) 1px, transparent 1px);
        background-size: 5px 5px;
        pointer-events: none;
        animation: gridPulse 5s ease-in-out infinite;
    }

    @keyframes gridPulse {

        0%,
        100% {
            opacity: 0.06;
        }

        50% {
            opacity: 0.12;
        }
    }

    .crt-scan {
        position: fixed;
        inset: 0;
        background: repeating-linear-gradient(to bottom,
                transparent 0%,
                rgba(0, 0, 0, 0.12) 1px,
                transparent 2px);
        pointer-events: none;
        opacity: 0.5;
        animation: scan 10s linear infinite;
    }

    @keyframes scan {
        0% {
            transform: translateY(-100%);
        }

        100% {
            transform: translateY(100%);
        }
    }

    .container {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        padding: 20px;
        position: relative;
        z-index: 1;
    }

    .main-panel {
        background: rgba(8, 8, 18, 0.88);
        border: 1px solid rgba(0, 240, 255, 0.14);
        border-radius: 12px;
        padding: 60px 40px;
        max-width: 450px;
        width: 100%;
        backdrop-filter: blur(18px);
        box-shadow: 0 0 35px rgba(0, 240, 255, 0.18);
        position: relative;
    }

    .main-panel::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent, #00f0ff, transparent);
        opacity: 0.4;
    }

    .ai-header {
        text-align: center;
        margin-bottom: 50px;
    }

    .ai-title {
        font-family: 'VT323', monospace;
        font-size: 2.1rem;
        color: #00f0ff;
        text-shadow: 0 0 12px #00f0ff77;
        letter-spacing: 3px;
        margin-bottom: 8px;
    }

    .ai-subtitle {
        font-size: 0.95rem;
        color: #ff00aa;
        text-shadow: 0 0 8px #ff00aa55;
        font-weight: 300;
        letter-spacing: 1.5px;
    }

    .query-categories {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .category {
        background: rgba(0, 0, 0, 0.45);
        border: 1px solid rgba(0, 240, 255, 0.12);
        border-radius: 10px;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .category:hover {
        border-color: rgba(0, 240, 255, 0.3);
        box-shadow: 0 0 20px rgba(0, 240, 255, 0.2);
    }

    .category-header {
        padding: 18px 24px;
        background: rgba(0, 240, 255, 0.06);
        border-bottom: 1px solid rgba(0, 240, 255, 0.14);
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .category-header:hover {
        background: rgba(0, 240, 255, 0.1);
    }

    .category-title {
        font-size: 1.05rem;
        font-weight: 500;
        color: #e0f0ff;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .category-icon {
        font-size: 1.3rem;
        color: #00f0ff;
        filter: drop-shadow(0 0 5px currentColor);
    }

    .business-category {
        border: 1px solid rgba(255, 0, 170, 0.25);
        background: rgba(30, 5, 35, 0.5);
    }

    .business-category .category-header {
        background: rgba(255, 0, 170, 0.09);
        border-bottom: 1px solid rgba(255, 0, 170, 0.2);
    }

    .business-category .category-title {
        color: #ff99dd;
    }

    .business-category .category-icon {
        color: #ff00aa;
    }

    .category-arrow {
        font-size: 1rem;
        color: rgba(0, 240, 255, 0.6);
        transition: transform 0.3s ease;
    }

    .category.expanded .category-arrow {
        transform: rotate(90deg);
    }

    .query-list {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.4s ease;
    }

    .category.expanded .query-list {
        max-height: 1400px;
        /* Tüm VIP'leri kapsayacak kadar büyük */
    }

    .query-item {
        background: rgba(0, 0, 0, 0.4);
        border-bottom: 1px solid rgba(0, 240, 255, 0.08);
        padding: 16px 24px;
        cursor: pointer;
        transition: all 0.3s ease;
        position: relative;
    }

    .query-item:last-child {
        border-bottom: none;
    }

    .query-item:hover {
        background: rgba(0, 240, 255, 0.08);
        transform: translateX(5px);
    }

    .query-label {
        font-size: 0.95rem;
        font-weight: 400;
        color: #ffffff;
        margin-bottom: 4px;
    }

    .query-desc {
        font-size: 0.8rem;
        color: rgba(0, 240, 255, 0.65);
        font-weight: 300;
        line-height: 1.3;
    }

    .status-bar {
        margin-top: 40px;
        padding: 16px 0;
        border-top: 1px solid rgba(0, 240, 255, 0.08);
        text-align: center;
    }

    .status-text {
        font-size: 0.8rem;
        color: #ff00aa;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .status-text:hover {
        color: #ff66cc;
        transform: scale(1.05);
    }

    .pulse-dot {
        display: inline-block;
        width: 8px;
        height: 8px;
        background: #ff00aa;
        border-radius: 50%;
        margin: 0 8px;
        box-shadow: 0 0 10px #ff00aa88;
        animation: pulse 2s ease-in-out infinite;
    }

    @keyframes pulse {

        0%,
        100% {
            opacity: 0.4;
            transform: scale(1);
        }

        50% {
            opacity: 1;
            transform: scale(1.3);
        }
    }

    @media (max-width: 768px) {
        .main-panel {
            padding: 40px 30px;
            margin: 20px;
        }

        .ai-title {
            font-size: 1.8rem;
        }

    }
    </style>
</head>

<body>

    <div class="ai-grid"></div>
    <div class="crt-scan"></div>

    <div class="container">
        <div class="main-panel">

            <div class="ai-header">
                <img src="assets/images/sex.png" alt="Bedava Sorgu Paneli - Ücretsiz T.C., GSM, Adres Sorgu"
                    style="max-width: 200px; height: auto; margin-bottom: 10px; image-rendering: pixelated;">
                <div class="ai-subtitle">BEDAVA SORGU PANELİ 2026</div>
                <div style="font-size: 0.7rem; color: rgba(0, 240, 255, 0.5); margin-top: 5px;">
                    ✅ %100 Ücretsiz ⚡ Hızlı Sonuç 🔒 Güvenli
                </div><br>
            </div>

            <div class="query-categories">

                <!-- Kişisel Sorgular -->
                <div class="category" onclick="toggleCategory(this)">
                    <div class="category-header">
                        <div class="category-title">
                            <span class="category-icon">👤</span> Kişisel Sorgular
                        </div>
                        <span class="category-arrow">▶</span>
                    </div>
                    <div class="query-list">
                        <div class="query-item" onclick="executeQuery('adsoyad.php')">
                            <div class="query-label">Ad Soyad Sorgu</div>
                            <div class="query-desc">İsim, soyisim bazlı veriler ile sorgulama</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('tcsorgu.php')">
                            <div class="query-label">T.C. Sorgu</div>
                            <div class="query-desc">T.C. kimlik numarası ile kimlik bilgilerini sorgula</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('gsmtc.php')">
                            <div class="query-label">GSM → T.C. Sorgu</div>
                            <div class="query-desc">GSM numarası ile T.C. kimlik numarasını sorgula</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('tcgsm.php')">
                            <div class="query-label">T.C. → GSM Sorgu</div>
                            <div class="query-desc">T.C. kimlik numarası ile GSM bilgilerini sorgula</div>
                        </div>
                    </div>
                </div>

                <!-- Konut & Adres -->
                <div class="category" onclick="toggleCategory(this)">
                    <div class="category-header">
                        <div class="category-title">
                            <span class="category-icon">🏠</span> Konut & Adres
                        </div>
                        <span class="category-arrow">▶</span>
                    </div>
                    <div class="query-list">
                        <div class="query-item" onclick="executeQuery('adres.php')">
                            <div class="query-label">Adres Sorgu</div>
                            <div class="query-desc">T.C. ile adres bilgilerini sorgula</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('hane.php')">
                            <div class="query-label">Hane Sorgu</div>
                            <div class="query-desc">T.C. ile hane bilgilerini sorgula</div>
                        </div>
                         <div class="query-item" onclick="executeQuery('sokak.php')">
                            <div class="query-label">Sokak Sorgu</div>
                            <div class="query-desc">T.C. ile sokak bilgilerini sorgula</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('tapu.php')">
                            <div class="query-label">Tapu Sorgu</div>
                            <div class="query-desc">T.C. ile tapu bilgilerini sorgula</div>
                        </div>
                    </div>
                </div>

                <!--  & Soy -->
                <div class="category" onclick="toggleCategory(this)">
                    <div class="category-header">
                        <div class="category-title">
                            <span class="category-icon">👨‍👩‍👧‍👦</span> & Soy
                        </div>
                        <span class="category-arrow">▶</span>
                    </div>
                    <div class="query-list">
                        <div class="query-item" onclick="executeQuery('aile.php')">
                            <div class="query-label"> Aile Sorgu</div>
                            <div class="query-desc">T.C. ile bilgilerini sorgula</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('sülale.php')">
                            <div class="query-label">Soyağacı Sorgu</div>
                            <div class="query-desc">T.C. ile soyağacı bilgilerini sorgula</div>
                        </div>
                    </div>
                </div>
                <div class="category" onclick="toggleCategory(this)">
                    <div class="category-header">
                        <div class="category-title">
                            <span class="category-icon">🖼️</span> Vesikalık Çözümler
                        </div>
                        <span class="category-arrow">▶</span>
                    </div>
                    <div class="query-list">
                        <div class="query-item" onclick="executeQuery('eokulvesika.php')">
                            <div class="query-label">E-Okul Vesika Sorgu</div>
                            <div class="query-desc">E-Okul vesikalık fotoğraf sorgulama işlemi</div>
                        </div>
                    </div>
                </div>

                <!-- VIP+ Pro Sorgular -->
                <div class="category business-category" onclick="toggleCategory(this)">
                    <div class="category-header">
                        <div class="category-title">
                            <span class="category-icon">👑</span> VIP+ Pro Sorgular
                        </div>
                        <span class="category-arrow">▶</span>
                    </div>
                    <div class="query-list">
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">Güncel T.C. Pro Sorgu</div>
                            <div class="query-desc">Gelişmiş T.C. kimlik analizi ve detayları</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">Güncel Adres Sorgu</div>
                            <div class="query-desc">En güncel adres bilgileri ve geçmiş</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">Güncel Tapu Sorgu</div>
                            <div class="query-desc">Güncel tapu kayıtları ve mülkiyet bilgileri</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">Güncel T.C. → GSM</div>
                            <div class="query-desc">T.C. ile güncel GSM numaralarını sorgula</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">Güncel GSM → T.C.</div>
                            <div class="query-desc">GSM ile güncel T.C. kimlik sorgulama</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">Güncel Sorgu</div>
                            <div class="query-desc">Güncel bilgileri ve kayıtları</div>
                        </div>
                    </div>
                </div>

                <!-- VIP+ Lokasyon & Araç -->
                <div class="category business-category" onclick="toggleCategory(this)">
                    <div class="category-header">
                        <div class="category-title">
                            <span class="category-icon">🚗</span> VIP+ Lokasyon & Araç
                        </div>
                        <span class="category-arrow">▶</span>
                    </div>
                    <div class="query-list">
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">Whatsapp Takibi</div>
                            <div class="query-desc">GSM numarası ile whatsapp takibi</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">GSM → Anlık Konum</div>
                            <div class="query-desc">GSM numarası ile anlık konum tespiti (NETGSM HARİCİ TÜM ÖPERATÖRLER
                                ÇIKAR)</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">Güncel Plaka Sorgu</div>
                            <div class="query-desc">Araç plaka sorguları ve detayları</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">T.C. → Araç Sorgu</div>
                            <div class="query-desc">T.C. ile araç kayıtları ve detayları</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">Güncel Ada Parsel Sorgu</div>
                            <div class="query-desc">Ada parsel bilgileri ve analizi</div>
                        </div>
                    </div>
                </div>

                <!-- VIP+ Geçmiş & Kayıtlar -->
                <div class="category business-category" onclick="toggleCategory(this)">
                    <div class="category-header">
                        <div class="category-title">
                            <span class="category-icon">📋</span> VIP+ Geçmiş & Kayıtlar
                        </div>
                        <span class="category-arrow">▶</span>
                    </div>
                    <div class="query-list">
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">T.C. → Hastane Geçmişi</div>
                            <div class="query-desc">Hastane geçmiş kayıtları</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">T.C. → Konaklama Geçmişi</div>
                            <div class="query-desc">Otel ve konaklama geçmiş kayıtları</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">T.C. → Yeni Kimlik Vesika</div>
                            <div class="query-desc">Yeni kimlik belgesi bilgileri</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">T.C. → Eğitim Hayatı</div>
                            <div class="query-desc">Eğitim geçmişi ve okul kayıtları</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">GSM → HTS Kaydı</div>
                            <div class="query-desc">GSM ile HTS sistemi kayıtları</div>
                        </div>
                    </div>
                </div>

                <!-- VIP+ İş & Finans -->
                <div class="category business-category" onclick="toggleCategory(this)">
                    <div class="category-header">
                        <div class="category-title">
                            <span class="category-icon">💰</span> VIP+ İş & Finans
                        </div>
                        <span class="category-arrow">▶</span>
                    </div>
                    <div class="query-list">
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">IBAN → T.C.</div>
                            <div class="query-desc">IBAN numarası ile T.C. kimlik sorgulama</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">T.C. → İşyeri Sorgu</div>
                            <div class="query-desc">İşyeri kayıtları ve ticari bilgiler</div>
                        </div>
                        <div class="query-item" onclick="executeQuery('pay.html')">
                            <div class="query-label">T.C. → Şirket Sorgu</div>
                            <div class="query-desc">Şirket ortaklıkları ve ticari faaliyetler</div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="status-bar">
                <div class="status-text" onclick="openTelegram()">
                    <i class="pulse-dot"></i> TIKLA TELEGRAM KANALIMIZA KATIL
                </div>
            </div>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    window.addEventListener("load", function() {
        Swal.fire({
            title: "Telegram Kanalımıza Katıl!",
            text: "Eski Grubumuz Kapanmıştır Yeni Telegram Adresimiz.",
            icon: "info",
            showConfirmButton: true,
            showDenyButton: true,
            confirmButtonText: "Telegram'a Katıl",
            denyButtonText: "Daha Sonra",
            allowOutsideClick: false,
            allowEscapeKey: false,
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "https://t.me/belsisorg";
            }
        });
    });

    function toggleCategory(categoryElement) {
        if (event.target.closest('.query-item')) return;
        categoryElement.classList.toggle('expanded');
    }

    function executeQuery(protocol) {
        event.stopPropagation();
        const item = event.target.closest('.query-item');
        item.style.background = 'rgba(0, 240, 255, 0.18)';
        setTimeout(() => {
            window.location.href = `${protocol}`;
        }, 200);
    }

    function openTelegram() {
        window.open('https://t.me/belsisorg', '_blank');
    }

    document.addEventListener('DOMContentLoaded', function() {
        const panel = document.querySelector('.main-panel');
        panel.style.opacity = '0';
        panel.style.transform = 'translateY(20px)';
        setTimeout(() => {
            panel.style.transition = 'all 0.8s ease';
            panel.style.opacity = '1';
            panel.style.transform = 'translateY(0)';
        }, 100);

        const firstCategory = document.querySelector('.category');
        if (firstCategory) firstCategory.classList.add('expanded');
    });
    </script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"6d4f86e12adf4d968b54383ca34ca6a5","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>

</html>